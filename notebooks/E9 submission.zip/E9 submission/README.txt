I provide 2 versions of the assignment.
The Jupiter notebook is completely identical in both cases,
But 1 version has the sound files already downloaded in the subfolders,
The other version has only empty subfolders (the code will download the files anyway).

Thanks